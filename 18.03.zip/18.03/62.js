const arr = [10, 20, 30, 40, 50];
console.log(arr[0]);
console.log(arr[arr.length - 1]);
console.log(arr[arr.length - 2]);