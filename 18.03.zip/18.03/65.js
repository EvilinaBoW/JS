const arr = [1, 2, 3, 4];
arr.pop();
arr.shift();
console.log(arr);