const map = new Map([["a", 1], ["b", 2]]);
for (let [key, value] of map) console.log(key, value);